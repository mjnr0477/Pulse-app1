// components/PostInput.js
import React, { useState } from 'react';
import { View, TextInput, TouchableOpacity, Text, StyleSheet } from 'react-native';

export default function PostInput({ onPost }) {
  const [text, setText] = useState('');

  const submit = () => {
    onPost(text);
    setText('');
  };

  return (
    <View style={styles.container}>
      <TextInput
        value={text}
        onChangeText={setText}
        placeholder='Share something...'
        placeholderTextColor='#888'
        style={styles.input}
      />
      <TouchableOpacity style={styles.button} onPress={submit}>
        <Text style={styles.btnText}>Post</Text>
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flexDirection: 'row', padding: 12, borderBottomWidth: 1, borderColor: '#111' },
  input: { flex: 1, backgroundColor: '#111', color: '#fff', padding: 10, borderRadius: 8, marginRight: 8 },
  button: { backgroundColor: '#ff0055', paddingHorizontal: 16, justifyContent: 'center', borderRadius: 8 },
  btnText: { color: '#fff', fontWeight: 'bold' }
});
