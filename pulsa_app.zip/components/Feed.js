// components/Feed.js
import React from 'react';
import { View, Text, FlatList, StyleSheet } from 'react-native';

export default function Feed({ posts }) {
  return (
    <FlatList
      data={posts}
      keyExtractor={item => item.id}
      contentContainerStyle={{ padding: 16 }}
      renderItem={({ item }) => (
        <View style={styles.post}>
          <Text style={styles.text}>{item.text}</Text>
          <Text style={styles.time}>{item.createdAt?.toDate ? item.createdAt.toDate().toLocaleString() : ''}</Text>
        </View>
      )}
    />
  );
}

const styles = StyleSheet.create({
  post: { backgroundColor: '#111', padding: 12, borderRadius: 8, marginBottom: 10 },
  text: { color: '#fff' },
  time: { color: '#888', fontSize: 12, marginTop: 6 }
});
