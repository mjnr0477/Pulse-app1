// App.js - Pulsa starter (Feed + Post) - Expo
import React, { useState, useEffect } from 'react';
import { SafeAreaView, View, Text, TextInput, TouchableOpacity, FlatList, StyleSheet, StatusBar } from 'react-native';
import { db } from './firebaseConfig';
import { collection, addDoc, onSnapshot, query, orderBy, serverTimestamp } from 'firebase/firestore';
import Feed from './components/Feed';
import PostInput from './components/PostInput';

export default function App() {
  const [posts, setPosts] = useState([]);

  useEffect(() => {
    const q = query(collection(db, 'posts'), orderBy('createdAt', 'desc'));
    const unsub = onSnapshot(q, (snapshot) => {
      setPosts(snapshot.docs.map(d => ({ id: d.id, ...d.data() })));
    }, (err) => {
      console.log('Firestore snapshot error', err);
    });
    return unsub;
  }, []);

  const addPost = async (text) => {
    if (!text || !text.trim()) return;
    try {
      await addDoc(collection(db, 'posts'), {
        text: text.trim(),
        createdAt: serverTimestamp()
      });
    } catch (err) {
      console.log('addPost error', err);
    }
  };

  return (
    <SafeAreaView style={styles.container}>
      <StatusBar barStyle="light-content" />
      <View style={styles.header}>
        <Text style={styles.title}>Pulsa — Live Feed</Text>
      </View>

      <PostInput onPost={addPost} />

      <Feed posts={posts} />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#000' },
  header: { padding: 16, borderBottomWidth: 1, borderColor: '#111' },
  title: { color: '#fff', fontSize: 20, fontWeight: 'bold' }
});
