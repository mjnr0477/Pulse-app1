# Pulsa App (Starter ZIP)

This is a starter Expo project for **Pulsa** — a simple live feed prototype that connects to your Firebase project (pulse-f5547).

## Included
- App.js (main entry)
- firebaseConfig.js (your Firebase config)
- package.json
- app.json
- components/Feed.js
- components/PostInput.js
- assets placeholders
- README.md

## How to use
1. Unzip and push this folder to a **new GitHub repository** (root must contain package.json & App.js).
2. In the project root, open `firebaseConfig.js` and confirm the config values (already filled).
3. On a computer: run `npm install` then `npx expo start`.
   On phone: import to Snack (some APIs limited) or use Expo.dev to build.

## Firebase
This package expects Firestore rules to allow writes for testing. For quick testing you can use:

```
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    match /{document=**} {
      allow read, write: if true;
    }
  }
}
```

**Important**: Tighten rules before production.
